
const CreateOffer = () => {
  return (
    <div>CreateOffer</div>
  )
}

export default CreateOffer